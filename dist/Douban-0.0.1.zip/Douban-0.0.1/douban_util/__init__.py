#! /usr/bin/env python2.7
# coding=utf-8
__author__ = 'bulu_dog'

print('__init__.__name__', __name__)