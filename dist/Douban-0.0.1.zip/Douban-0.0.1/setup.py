# coding=utf-8
__author__ = 'bulu_dog'
from distutils.core import setup

setup(
    name='Douban',
    version='0.0.1',
    packages=['douban_util'],
    url='',
    license='MIT',
    author='LoveLYJ',
    author_email='zzzvvvxxxd@gmail.com',
    description=u'抓取豆瓣内容模组'
)
